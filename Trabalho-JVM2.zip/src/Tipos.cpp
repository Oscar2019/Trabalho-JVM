#include "../include/Tipos.h"
#include <iomanip>


template<>
uint8_t read<uint8_t>(uint8_t *in){
    uint8_t res = 0;
    res = *in;
    return res;
}

template<>
uint16_t read<uint16_t>(uint8_t *in){
    uint16_t res = 0;
    res = (res << 8) | read<uint8_t>(in + 0);
    res = (res << 8) | read<uint8_t>(in + 1);
    return res;
}

template<>
uint32_t read<uint32_t>(uint8_t *in){
    uint32_t res = 0;
    res = (res << 8) | read<uint8_t>(in + 0);
    res = (res << 8) | read<uint8_t>(in + 1);
    res = (res << 8) | read<uint8_t>(in + 2);
    res = (res << 8) | read<uint8_t>(in + 3);
    return res;
}

template<>
uint8_t read<uint8_t>(std::ifstream &ifs){
    uint8_t res = 0;
    ifs.read((char*)&res, 1);
    return res;
}

template<>
uint16_t read<uint16_t>(std::ifstream &ifs){
    uint16_t res = 0;
    res = (res << 8) | read<uint8_t>(ifs);
    res = (res << 8) | read<uint8_t>(ifs);
    return res;
}

template<>
uint32_t read<uint32_t>(std::ifstream &ifs){
    uint32_t res = 0;
    res = (res << 8) | read<uint8_t>(ifs);
    res = (res << 8) | read<uint8_t>(ifs);
    res = (res << 8) | read<uint8_t>(ifs);
    res = (res << 8) | read<uint8_t>(ifs);
    return res;
}

template<>
void print<uint8_t>(uint8_t& u, std::ostream &os){
    os << std::setfill('0') << std::setw(2) << std::right << std::hex << (uint32_t)u << "\n";
}

template<>
void print<uint16_t>(uint16_t& u, std::ostream &os){
    os << std::setfill('0') << std::setw(2) << std::right << std::hex << ((((uint32_t)u) >> 8) & 0xFF) << " ";
    os << std::setfill('0') << std::setw(2) << std::right << std::hex << ((((uint32_t)u) >> 0) & 0xFF) << "\n";
}

template<>
void print<uint32_t>(uint32_t& u, std::ostream &os){
    os << std::setfill('0') << std::setw(2) << std::right << std::hex << ((((uint32_t)u) >> 24) & 0xFF) << " ";
    os << std::setfill('0') << std::setw(2) << std::right << std::hex << ((((uint32_t)u) >> 16) & 0xFF) << " ";
    os << std::setfill('0') << std::setw(2) << std::right << std::hex << ((((uint32_t)u) >> 8) & 0xFF) << " ";
    os << std::setfill('0') << std::setw(2) << std::right << std::hex << ((((uint32_t)u) >> 0) & 0xFF) << "\n";
}


template<>
ClassFile read<ClassFile>(std::ifstream &ifs){
    ClassFile cf;
    cf.magic = read<uint32_t>(ifs);
    cf.minorVersion = read<uint16_t>(ifs);
    cf.majorVersion = read<uint16_t>(ifs);
    cf.constantPoolCount = read<uint16_t>(ifs);
    cf.constantPool = new ConstantPoolInfo*[cf.constantPoolCount];
    cf.constantPool[0] = nullptr;
    for(uint32_t i = 0; i < cf.constantPoolCount; i++){
        cf.constantPool[i] = nullptr;
    }
    for(uint32_t i = 1; i < cf.constantPoolCount; i++){
        if(cf.constantPool[i-1] == nullptr || (cf.constantPool[i-1]->tag != ConstantPoolInfoTag::LONG && cf.constantPool[i-1]->tag != ConstantPoolInfoTag::DOUBLE)){
            cf.constantPool[i] = read<ConstantPoolInfo*>(ifs);
        }
    }
    cf.accessFlags = read<uint16_t>(ifs);
    cf.thisClass = read<uint16_t>(ifs);
    cf.superClass = read<uint16_t>(ifs);
    cf.interfacesCount = read<uint16_t>(ifs);
    if(cf.interfacesCount > 0){
        cf.interfaces = new uint16_t[cf.interfacesCount];
        for(uint32_t i = 0; i < cf.interfacesCount; i++){
            cf.interfaces[i] = read<uint16_t>(ifs);
        }
    }
    cf.fieldsCount = read<uint16_t>(ifs);
    if(cf.fieldsCount > 0){
        cf.fields = new FieldInfo[cf.fieldsCount];
        for(uint32_t i = 0; i < cf.fieldsCount; i++){
            cf.fields[i] = read<FieldInfo>(ifs);
        }
    }
    cf.methodsCount = read<uint16_t>(ifs);
    if(cf.methodsCount > 0){
        cf.methods = new MethodInfo[cf.methodsCount];
        for(uint32_t i = 0; i < cf.methodsCount; i++){
            cf.methods[i] = read<MethodInfo>(ifs);
        }
    }
    cf.attributesCount = read<uint16_t>(ifs);
    if(cf.attributesCount > 0){
        cf.attributes = new AttributeInfo*[cf.attributesCount];
        for(uint32_t i = 0; i < cf.attributesCount; i++){
            cf.attributes[i] = read<AttributeInfoBasic*>(ifs);
        }
    }
    return cf;
}

template<>
void print<ClassFile>(ClassFile& u, std::ostream &os){
    print<uint32_t>(u.magic, os);
    print<uint16_t>(u.minorVersion, os);
    print<uint16_t>(u.majorVersion, os);
    print<uint16_t>(u.constantPoolCount, os);
    for(uint32_t i = 0; i < u.constantPoolCount; i++){
        if(u.constantPool[i] != nullptr){
            print<ConstantPoolInfo>(*u.constantPool[i], os);
        }
    }
    print<uint16_t>(u.accessFlags, os);
    print<uint16_t>(u.thisClass, os);
    print<uint16_t>(u.superClass, os);
    print<uint16_t>(u.interfacesCount, os);
    for(uint32_t i = 0; i < u.interfacesCount; i++){
        print<uint16_t>(u.interfaces[i], os);
    }
    print<uint16_t>(u.fieldsCount, os);
    for(uint32_t i = 0; i < u.fieldsCount; i++){
        print<FieldInfo>(u.fields[i], os);
    }
    print<uint16_t>(u.methodsCount, os);
    for(uint32_t i = 0; i < u.methodsCount; i++){
        print<MethodInfo>(u.methods[i], os);
    }
    print<uint16_t>(u.attributesCount, os);
    for(uint32_t i = 0; i < u.attributesCount; i++){
        print<AttributeInfoBasic>(*(AttributeInfoBasic*)u.attributes[i], os);
    }
}


template<>
ConstantPoolInfo* read<ConstantPoolInfo*>(std::ifstream &ifs){
    ConstantPoolInfo* ans = nullptr;
    uint8_t tag = 0;
    tag = read<uint8_t>(ifs);
    switch (tag){
        case ConstantPoolInfoTag::CLASS:
            ans = read<CPClass*>(ifs);
            ans->tag = tag;
            break;
        case ConstantPoolInfoTag::FIELDREF:
            ans = read<CPFieldref*>(ifs);
            ans->tag = tag;
            break;
        case ConstantPoolInfoTag::METHODREF:
            ans = read<CPMethodref*>(ifs);
            ans->tag = tag;
            break;
        case ConstantPoolInfoTag::INTERFACE_METHODREF:
            ans = read<CPInterfaceMethodref*>(ifs);
            ans->tag = tag;
            break;
        case ConstantPoolInfoTag::STRING:
            ans = read<CPString*>(ifs);
            ans->tag = tag;
            break;
        case ConstantPoolInfoTag::INTEGER:
            ans = read<CPInteger*>(ifs);
            ans->tag = tag;
            break;
        case ConstantPoolInfoTag::FLOAT:
            ans = read<CPFloat*>(ifs);
            ans->tag = tag;
            break;
        case ConstantPoolInfoTag::LONG:
            ans = read<CPLong*>(ifs);
            ans->tag = tag;
            break;
        case ConstantPoolInfoTag::DOUBLE:
            ans = read<CPDouble*>(ifs);
            ans->tag = tag;
            break;
        case ConstantPoolInfoTag::NAME_AND_TYPE:
            ans = read<CPNameAndType*>(ifs);
            ans->tag = tag;
            break;
        case ConstantPoolInfoTag::UTF8:
            ans = read<CPUtf8*>(ifs);
            ans->tag = tag;
            break;
        case ConstantPoolInfoTag::METHOD_HANDLE:
            ans = read<CPMethodHandle*>(ifs);
            ans->tag = tag;
            break;
        case ConstantPoolInfoTag::METHOD_TYPE:
            ans = read<CPMethodType*>(ifs);
            ans->tag = tag;
            break;
        case ConstantPoolInfoTag::INVOKE_DYNAMIC:
            ans = read<CPInvokeDynamic*>(ifs);
            ans->tag = tag;
            break;
        default:
            break;
    }
    return ans;
}

template<>
CPClass* read<CPClass*>(std::ifstream &ifs){
    CPClass* ans = new CPClass();
    ans->nameIndex = read<uint16_t>(ifs);
    return ans;
}

template<>
CPFieldref* read<CPFieldref*>(std::ifstream &ifs){
    CPFieldref* ans = new CPFieldref();
    ans->classIndex = read<uint16_t>(ifs);
    ans->nameAndTypeIndex = read<uint16_t>(ifs);
    return ans;
}

template<>
CPMethodref* read<CPMethodref*>(std::ifstream &ifs){
    CPMethodref* ans = new CPMethodref();
    ans->classIndex = read<uint16_t>(ifs);
    ans->nameAndTypeIndex = read<uint16_t>(ifs);
    return ans;
}

template<>
CPInterfaceMethodref* read<CPInterfaceMethodref*>(std::ifstream &ifs){
    CPInterfaceMethodref* ans = new CPInterfaceMethodref();
    ans->classIndex = read<uint16_t>(ifs);
    ans->nameAndTypeIndex = read<uint16_t>(ifs);
    return ans;
}

template<>
CPString* read<CPString*>(std::ifstream &ifs){
    CPString* ans = new CPString();
    ans->stringIndex = read<uint16_t>(ifs);
    return ans;
}

template<>
CPInteger* read<CPInteger*>(std::ifstream &ifs){
    CPInteger* ans = new CPInteger();
    ans->bytes = read<uint32_t>(ifs);
    return ans;
}

template<>
CPFloat* read<CPFloat*>(std::ifstream &ifs){
    CPFloat* ans = new CPFloat();
    ans->bytes = read<uint32_t>(ifs);
    return ans;
}

template<>
CPLong* read<CPLong*>(std::ifstream &ifs){
    CPLong* ans = new CPLong();
    ans->highBytes = read<uint32_t>(ifs);
    ans->lowBytes = read<uint32_t>(ifs);
    return ans;
}

template<>
CPDouble* read<CPDouble*>(std::ifstream &ifs){
    CPDouble* ans = new CPDouble();
    ans->highBytes = read<uint32_t>(ifs);
    ans->lowBytes = read<uint32_t>(ifs);
    return ans;
}

template<>
CPNameAndType* read<CPNameAndType*>(std::ifstream &ifs){
    CPNameAndType* ans = new CPNameAndType();
    ans->nameIndex = read<uint16_t>(ifs);
    ans->descriptorIndex = read<uint16_t>(ifs);
    return ans;
}

template<>
CPUtf8* read<CPUtf8*>(std::ifstream &ifs){
    CPUtf8* ans = new CPUtf8();
    ans->length = read<uint16_t>(ifs);
    ans->bytes = new uint8_t[ans->length];
    for(uint32_t i = 0; i < ans->length; i++){
        ans->bytes[i] = read<uint8_t>(ifs);
    }
    return ans;
}

template<>
CPMethodHandle* read<CPMethodHandle*>(std::ifstream &ifs){
    CPMethodHandle* ans = new CPMethodHandle();
    ans->referenceKind = read<uint8_t>(ifs);
    ans->referenceIndex = read<uint16_t>(ifs);
    return ans;
}

template<>
CPMethodType* read<CPMethodType*>(std::ifstream &ifs){
    CPMethodType* ans = new CPMethodType();
    ans->descriptorIndex = read<uint16_t>(ifs);
    return ans;
}

template<>
CPInvokeDynamic* read<CPInvokeDynamic*>(std::ifstream &ifs){
    CPInvokeDynamic* ans = new CPInvokeDynamic();
    ans->bootstrapMethodAttrIndex = read<uint16_t>(ifs);
    ans->nameAndTypeIndex = read<uint16_t>(ifs);
    return ans;
}


template<>
void print<ConstantPoolInfo>(ConstantPoolInfo& u, std::ostream &os){
    switch (u.tag){
        case ConstantPoolInfoTag::CLASS:
            print<CPClass>(*((CPClass*)&u), os);
            break;
        case ConstantPoolInfoTag::FIELDREF:
            print<CPFieldref>(*((CPFieldref*)&u), os);
            break;
        case ConstantPoolInfoTag::METHODREF:
            print<CPMethodref>(*((CPMethodref*)&u), os);
            break;
        case ConstantPoolInfoTag::INTERFACE_METHODREF:
            print<CPInterfaceMethodref>(*((CPInterfaceMethodref*)&u), os);
            break;
        case ConstantPoolInfoTag::STRING:
            print<CPString>(*((CPString*)&u), os);
            break;
        case ConstantPoolInfoTag::INTEGER:
            print<CPInteger>(*((CPInteger*)&u), os);
            break;
        case ConstantPoolInfoTag::FLOAT:
            print<CPFloat>(*((CPFloat*)&u), os);
            break;
        case ConstantPoolInfoTag::LONG:
            print<CPLong>(*((CPLong*)&u), os);
            break;
        case ConstantPoolInfoTag::DOUBLE:
            print<CPDouble>(*((CPDouble*)&u), os);
            break;
        case ConstantPoolInfoTag::NAME_AND_TYPE:
            print<CPNameAndType>(*((CPNameAndType*)&u), os);
            break;
        case ConstantPoolInfoTag::UTF8:
            print<CPUtf8>(*((CPUtf8*)&u), os);
            break;
        case ConstantPoolInfoTag::METHOD_HANDLE:
            print<CPMethodHandle>(*((CPMethodHandle*)&u), os);
            break;
        case ConstantPoolInfoTag::METHOD_TYPE:
            print<CPMethodType>(*((CPMethodType*)&u), os);
            break;
        case ConstantPoolInfoTag::INVOKE_DYNAMIC:
            print<CPInvokeDynamic>(*((CPInvokeDynamic*)&u), os);
            break;
        default:
            break;
    }
}

template<>
void print<CPClass>(CPClass& u, std::ostream &os){
    print<uint8_t>(u.tag, os);
    print<uint16_t>(u.nameIndex, os);
}

template<>
void print<CPFieldref>(CPFieldref& u, std::ostream &os){
    print<uint8_t>(u.tag, os);
    print<uint16_t>(u.classIndex, os);
    print<uint16_t>(u.nameAndTypeIndex, os);
}

template<>
void print<CPMethodref>(CPMethodref& u, std::ostream &os){
    print<uint8_t>(u.tag, os);
    print<uint16_t>(u.classIndex, os);
    print<uint16_t>(u.nameAndTypeIndex, os);
}

template<>
void print<CPInterfaceMethodref>(CPInterfaceMethodref& u, std::ostream &os){
    print<uint8_t>(u.tag, os);
    print<uint16_t>(u.classIndex, os);
    print<uint16_t>(u.nameAndTypeIndex, os);
}

template<>
void print<CPString>(CPString& u, std::ostream &os){
    print<uint8_t>(u.tag, os);
    print<uint16_t>(u.stringIndex, os);
}

template<>
void print<CPInteger>(CPInteger& u, std::ostream &os){
    print<uint8_t>(u.tag, os);
    os << *(int32_t*)(&u.bytes) << "\n";
}

template<>
void print<CPFloat>(CPFloat& u, std::ostream &os){
    print<uint8_t>(u.tag, os);
    os << *(float*)(&u.bytes) << "\n";
}

template<>
void print<CPLong>(CPLong& u, std::ostream &os){
    int64_t aux = 0;
    print<uint8_t>(u.tag, os);
    aux = (aux << 32) | u.highBytes;
    aux = (aux << 32) | u.highBytes;
    os << *(int64_t*)(&aux) << "\n";
}

template<>
void print<CPDouble>(CPDouble& u, std::ostream &os){
    int64_t aux = 0;
    print<uint8_t>(u.tag, os);
    aux = (aux << 32) | u.highBytes;
    aux = (aux << 32) | u.highBytes;
    os << *(double*)(&aux) << "\n";
}

template<>
void print<CPNameAndType>(CPNameAndType& u, std::ostream &os){
    print<uint8_t>(u.tag, os);
    print<uint16_t>(u.nameIndex, os);
    print<uint16_t>(u.descriptorIndex, os);
}

template<>
void print<CPUtf8>(CPUtf8& u, std::ostream &os){
    print<uint8_t>(u.tag, os);
    print<uint16_t>(u.length, os);
    os << std::string((const char*)u.bytes, u.length) << "\n";
}

template<>
void print<CPMethodHandle>(CPMethodHandle& u, std::ostream &os){
    print<uint8_t>(u.tag, os);
    print<uint8_t>(u.referenceKind, os);
    print<uint16_t>(u.referenceIndex, os);
}

template<>
void print<CPMethodType>(CPMethodType& u, std::ostream &os){
    print<uint8_t>(u.tag, os);
    print<uint16_t>(u.descriptorIndex, os);
}

template<>
void print<CPInvokeDynamic>(CPInvokeDynamic& u, std::ostream &os){
    print<uint8_t>(u.tag, os);
    print<uint16_t>(u.bootstrapMethodAttrIndex, os);
    print<uint16_t>(u.nameAndTypeIndex, os);
}

template<>
FieldInfo read<FieldInfo>(std::ifstream &ifs){
    FieldInfo fi;
    fi.accessFlags = read<uint16_t>(ifs);
    fi.nameIndex = read<uint16_t>(ifs);
    fi.descriptorIndex = read<uint16_t>(ifs);
    fi.attributesCount = read<uint16_t>(ifs);
    fi.attributes = new AttributeInfo*[fi.attributesCount];
    for(uint32_t i = 0; i < fi.attributesCount; i++){
        fi.attributes[i] = read<AttributeInfoBasic*>(ifs);
    }
    return fi;
}

template<>
void print<FieldInfo>(FieldInfo& u, std::ostream &os){
    print<uint16_t>(u.accessFlags, os);
    print<uint16_t>(u.nameIndex, os);
    print<uint16_t>(u.descriptorIndex, os);
    print<uint16_t>(u.attributesCount, os);
    for(uint32_t i = 0; i < u.attributesCount; i++){
        print<AttributeInfoBasic>(*(AttributeInfoBasic*)u.attributes[i], os);
    }
    os << "\n";
}

template<>
MethodInfo read<MethodInfo>(std::ifstream &ifs){
    MethodInfo mi;
    mi.accessFlags = read<uint16_t>(ifs);
    mi.nameIndex = read<uint16_t>(ifs);
    mi.descriptorIndex = read<uint16_t>(ifs);
    mi.attributesCount = read<uint16_t>(ifs);
    mi.attributes = new AttributeInfo*[mi.attributesCount];
    for(uint32_t i = 0; i < mi.attributesCount; i++){
        mi.attributes[i] = read<AttributeInfoBasic*>(ifs);
    }
    return mi;
}

template<>
void print<MethodInfo>(MethodInfo& u, std::ostream &os){
    print<uint16_t>(u.accessFlags, os);
    print<uint16_t>(u.nameIndex, os);
    print<uint16_t>(u.descriptorIndex, os);
    print<uint16_t>(u.attributesCount, os);
    for(uint32_t i = 0; i < u.attributesCount; i++){
        print<AttributeInfo>(*(AttributeInfoBasic*)u.attributes[i], os);
    }
    os << "\n";
}


template<>
AttributeInfoBasic* read<AttributeInfoBasic*>(std::ifstream &ifs){
    AttributeInfoBasic* ai = new AttributeInfoBasic();
    ai->attributeNameIndex = read<uint16_t>(ifs);
    ai->attributeLength = read<uint32_t>(ifs);
    if(ai->attributeLength > 0){
        ai->info = new uint8_t[ai->attributeLength];
        for(uint32_t i = 0; i < ai->attributeLength; i++){
            ai->info[i] = read<uint8_t>(ifs);
        }
    }
    return ai;
}

template<>
void print<AttributeInfoBasic>(AttributeInfoBasic& u, std::ostream &os){
    print<uint16_t>(u.attributeNameIndex, os);
    print<uint32_t>(u.attributeLength, os);
    for(uint32_t i = 0; i < u.attributeLength; i++){
        os << std::setfill('0') << std::setw(2) << std::right << std::hex << (uint32_t)u.info[i];
        if(i + 1 != u.attributeLength){
            os << " ";
        } else{
            os << "\n";
        }
    }
    os << "\n";
}

