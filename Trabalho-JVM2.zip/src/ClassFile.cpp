#include "../include/ClassFile.h"
#include "../include/FieldInfo.h"
#include "../include/MethodInfo.h"

void conveterAttributeInfoInClassFile(ConstantPoolInfo **cpi, ClassFile *cf){
    for(uint32_t i = 0; i < cf->fieldsCount; i++){
        conveterAttributeInfoInFieldInfo(cpi, cf->fields + i);
    }
    for(uint32_t i = 0; i < cf->methodsCount; i++){
        conveterAttributeInfoInMethodInfo(cpi, cf->methods + i);
    }
    for(uint32_t i = 0; i < cf->attributesCount; i++){
        conveterAttributeInfoInAttributeInfo(cpi, cf->attributes + i);
    }
}