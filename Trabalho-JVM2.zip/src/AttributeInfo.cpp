#include "../include/AttributeInfo.h"
#include "../include/ConstantPoolInfo.h"
#include "../include/Tipos.h"

void conveterAttributeInfoInAttributeInfo(ConstantPoolInfo **cp, AttributeInfo **ai){
    std::string str = getCPUtf8(cp, (*ai)->attributeNameIndex);
    AttributeInfoBasic *aib = (AttributeInfoBasic*)*ai;
    if(str == "ConstantValue"){
        AttributeInfoConstantValue *nAi = new AttributeInfoConstantValue;
        nAi->attributeNameIndex = aib->attributeNameIndex;
        nAi->attributeLength = aib->attributeLength;
        nAi->constantvalueIndex = read<uint16_t>(aib->info);
        delete aib->info;
        delete aib;
        *ai = (AttributeInfo*)nAi;
    } else if(str == "Code"){
        AttributeInfoCode *nAi = new AttributeInfoCode;
        uint32_t offset = 0;
        nAi->attributeNameIndex = aib->attributeNameIndex;
        nAi->attributeLength = aib->attributeLength;
        nAi->maxStack = read<uint16_t>(aib->info + offset); offset+=2;
        nAi->maxLocals = read<uint16_t>(aib->info + offset); offset+=2;
        nAi->codeLength = read<uint32_t>(aib->info + offset); offset+=4;
        nAi->code = new uint8_t[nAi->codeLength];
        for(uint32_t i = 0; i < nAi->codeLength; i++){
            nAi->code[i] = read<uint8_t>(aib->info + offset); offset+=1;
        }
        nAi->exceptionTableLength = read<uint16_t>(aib->info + offset); offset+=2;
        nAi->exceptionTable = new AttributeInfoCode::ExceptionTable[nAi->exceptionTableLength];
        for(uint32_t i = 0; i < nAi->exceptionTableLength; i++){
            nAi->exceptionTable[i].startPc = read<uint16_t>(aib->info + offset); offset+=2;
            nAi->exceptionTable[i].endPc = read<uint16_t>(aib->info + offset); offset+=2;
            nAi->exceptionTable[i].handlerPc = read<uint16_t>(aib->info + offset); offset+=2;
            nAi->exceptionTable[i].catchType = read<uint16_t>(aib->info + offset); offset+=2;
        }
        nAi->attributesCount = read<uint16_t>(aib->info + offset); offset+=2;
        if(nAi->attributesCount > 0){
            nAi->attributes = new AttributeInfo*[nAi->attributesCount];
            for(uint32_t i = 0; i < nAi->attributesCount; i++){
                nAi->attributes[i] = new AttributeInfoBasic;
                AttributeInfoBasic *iAi = (AttributeInfoBasic*)nAi->attributes[i];
                iAi->attributeNameIndex = read<uint16_t>(aib->info + offset); offset+=2;
                iAi->attributeLength = read<uint32_t>(aib->info + offset); offset+=4;
                if(iAi->attributeLength > 0){
                    iAi->info = new uint8_t[iAi->attributeLength];
                    for(uint32_t i = 0; i < iAi->attributeLength; i++){
                        iAi->info[i] = read<uint8_t>(aib->info + offset); offset+=1;
                    }
                }
            }
        }
        delete aib->info;
        delete aib;
        *ai = (AttributeInfo*)nAi;
    } else if(str == "StackMapTable"){

    } else if(str == "Exceptions"){

    } else if(str == "InnerClasses"){

    } else if(str == "EnclosingMethod"){

    } else if(str == "Synthetic"){

    } else if(str == "Signature"){

    } else if(str == "SourceFile"){

    } else if(str == "SourceDebugExtension"){

    } else if(str == "LineNumberTable"){

    } else if(str == "LocalVariableTable"){

    } else if(str == "LocalVariableTypeTable"){

    } else if(str == "Deprecated"){

    } else if(str == "RuntimeVisibleAnnotations"){

    } else if(str == "RuntimeInvisibleAnnotations"){

    } else if(str == "RuntimeVisibleParameterAnnotations"){

    } else if(str == "RuntimeInvisibleParameterAnnotations"){

    } else if(str == "RuntimeVisibleTypeAnnotations"){

    } else if(str == "RuntimeInvisibleTypeAnnotations"){

    } else if(str == "AnnotationDefault"){

    } else if(str == "BootstrapMethods"){

    } else if(str == "MethodParameters"){

    } 
}
