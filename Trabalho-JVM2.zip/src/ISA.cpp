#include "../include/ISA.h"

const std::vector<uint32_t> qtdAttributes({
    0, // 0x00
    0, // 0x01
    0, // 0x02
    0, // 0x03
    0, // 0x04
    0, // 0x05
    0, // 0x06
    0, // 0x07
    0, // 0x08
    0, // 0x09
    0, // 0x0A
    0, // 0x0B
    0, // 0x0C
    0, // 0x0D
    0, // 0x0E
    0, // 0x0F
    1, // 0x10
    2, // 0x11
    1, // 0x12
    2, // 0x13
    2, // 0x14
    1, // 0x15
    1, // 0x16
    1, // 0x17
    1, // 0x18
    1, // 0x19
    0, // 0x1A
    0, // 0x1B
    0, // 0x1C
    0, // 0x1D
    0, // 0x1E
    0, // 0x1F
    0, // 0x20
    0, // 0x21
    0, // 0x22
    0, // 0x23
    0, // 0x24
    0, // 0x25
    0, // 0x26
    0, // 0x27
    0, // 0x28
    0, // 0x29
    0, // 0x2A
    0, // 0x2B
    0, // 0x2C
    0, // 0x2D
    0, // 0x2E
    0, // 0x2F
    0, // 0x30
    0, // 0x31
    0, // 0x32
    0, // 0x33
    0, // 0x34
    0, // 0x35
    1, // 0x36
    1, // 0x37
    1, // 0x38
    1, // 0x39
    1, // 0x3A
    0, // 0x3B
    0, // 0x3C
    0, // 0x3D
    0, // 0x3E
    0, // 0x3F
    0, // 0x40
    0, // 0x41
    0, // 0x42
    0, // 0x43
    0, // 0x44
    0, // 0x45
    0, // 0x46
    0, // 0x47
    0, // 0x48
    0, // 0x49
    0, // 0x4A
    0, // 0x4B
    0, // 0x4C
    0, // 0x4D
    0, // 0x4E
    0, // 0x4F
    0, // 0x50
    0, // 0x51
    0, // 0x52
    0, // 0x53
    0, // 0x54
    0, // 0x55
    0, // 0x56
    0, // 0x57
    0, // 0x58
    0, // 0x59
    0, // 0x5A
    0, // 0x5B
    0, // 0x5C
    0, // 0x5D
    0, // 0x5E
    0, // 0x5F
    0, // 0x60
    0, // 0x61
    0, // 0x62
    0, // 0x63
    0, // 0x64
    0, // 0x65
    0, // 0x66
    0, // 0x67
    0, // 0x68
    0, // 0x69
    0, // 0x6A
    0, // 0x6B
    0, // 0x6C
    0, // 0x6D
    0, // 0x6E
    0, // 0x6F
    0, // 0x70
    0, // 0x71
    0, // 0x72
    0, // 0x73
    0, // 0x74
    0, // 0x75
    0, // 0x76
    0, // 0x77
    0, // 0x78
    0, // 0x79
    0, // 0x7A
    0, // 0x7B
    0, // 0x7C
    0, // 0x7D
    0, // 0x7E
    0, // 0x7F
    0, // 0x80
    0, // 0x81
    0, // 0x82
    0, // 0x83
    2, // 0x84
    0, // 0x85
    0, // 0x86
    0, // 0x87
    0, // 0x88
    0, // 0x89
    0, // 0x8A
    0, // 0x8B
    0, // 0x8C
    0, // 0x8D
    0, // 0x8E
    0, // 0x8F
    0, // 0x90
    0, // 0x91
    0, // 0x92
    0, // 0x93
    0, // 0x94
    0, // 0x95
    0, // 0x96
    0, // 0x97
    0, // 0x98
    2, // 0x99
    2, // 0x9A
    2, // 0x9B
    2, // 0x9C
    2, // 0x9D
    2, // 0x9E
    2, // 0x9F
    2, // 0xA0
    2, // 0xA1
    2, // 0xA2
    2, // 0xA3
    2, // 0xA4
    2, // 0xA5
    2, // 0xA6
    2, // 0xA7
    2, // 0xA8
    1, // 0xA9
    0, // 0xAA Atenção
    0, // 0xAB Atenção
    0, // 0xAC
    0, // 0xAD
    0, // 0xAE
    0, // 0xAF
    0, // 0xB0
    0, // 0xB1
    2, // 0xB2
    2, // 0xB3
    2, // 0xB4
    2, // 0xB5
    2, // 0xB6
    2, // 0xB7
    2, // 0xB8
    4, // 0xB9 Atenção
    4, // 0xBA
    2, // 0xBB
    1, // 0xBC
    2, // 0xBD
    0, // 0xBE
    0, // 0xBF
    2, // 0xC0
    2, // 0xC1
    0, // 0xC2
    0, // 0xC3
    5, // 0xC4
    3, // 0xC5
    2, // 0xC6
    2, // 0xC7
    4, // 0xC8
    4, // 0xC9
    0, // 0xCA
    0, // 0xCB
    0, // 0xCC
    0, // 0xCD
    0, // 0xCE
    0, // 0xCF
    0, // 0xD0
    0, // 0xD1
    0, // 0xD2
    0, // 0xD3
    0, // 0xD4
    0, // 0xD5
    0, // 0xD6
    0, // 0xD7
    0, // 0xD8
    0, // 0xD9
    0, // 0xDA
    0, // 0xDB
    0, // 0xDC
    0, // 0xDD
    0, // 0xDE
    0, // 0xDF
    0, // 0xE0
    0, // 0xE1
    0, // 0xE2
    0, // 0xE3
    0, // 0xE4
    0, // 0xE5
    0, // 0xE6
    0, // 0xE7
    0, // 0xE8
    0, // 0xE9
    0, // 0xEA
    0, // 0xEB
    0, // 0xEC
    0, // 0xED
    0, // 0xEE
    0, // 0xEF
    0, // 0xF0
    0, // 0xF1
    0, // 0xF2
    0, // 0xF3
    0, // 0xF4
    0, // 0xF5
    0, // 0xF6
    0, // 0xF7
    0, // 0xF8
    0, // 0xF9
    0, // 0xFA
    0, // 0xFB
    0, // 0xFC
    0, // 0xFD
    0, // 0xFE
    0 // 0xFF
});

std::string printOp_nop(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "nop\n";
    return res;
}

std::string printOp_aconst_null(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "aconst_null\n";
    return res;
}

std::string printOp_iconst_m1(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "iconst_m1\n";
    return res;
}

std::string printOp_iconst_0(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "iconst_0\n";
    return res;
}

std::string printOp_iconst_1(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "iconst_1\n";
    return res;
}

std::string printOp_iconst_2(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "iconst_2\n";
    return res;
}

std::string printOp_iconst_3(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "iconst_3\n";
    return res;
}

std::string printOp_iconst_4(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "iconst_4\n";
    return res;
}

std::string printOp_iconst_5(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "iconst_5\n";
    return res;
}

std::string printOp_lconst_0(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "lconst_0\n";
    return res;
}

std::string printOp_lconst_1(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "lconst_1\n";
    return res;
}

std::string printOp_fconst_0(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "fconst_0\n";
    return res;
}

std::string printOp_fconst_1(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "fconst_1\n";
    return res;
}

std::string printOp_fconst_2(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "fconst_2\n";
    return res;
}

std::string printOp_dconst_0(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "dconst_0\n";
    return res;
}

std::string printOp_dconst_1(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "dconst_1\n";
    return res;
}

std::string printOp_bipush(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    int32_t byte = bytecode[0];
    res += "bipush " + std::to_string(byte);
    return res;
}

std::string printOp_sipush(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    int32_t byte = bytecode[0];
    byte = (byte << 8 ) | bytecode[1];
    res += "sipush " + std::to_string(byte);
    return res;
}

std::string printOp_ldc(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    uint32_t index = bytecode[0];
    res += "ldc #" + std::to_string(index);
    switch (cp[index]->tag){
        case ConstantPoolInfoTag::CLASS:{
            res += "<" + getClass(cp, index) + ">\n";
            }
            break;
        case ConstantPoolInfoTag::FIELDREF:{
            res += "<" + getFieldref(cp, index) + ">\n";
            }
            break;
        case ConstantPoolInfoTag::METHODREF:{
            res += "<" + getMethodref(cp, index) + ">\n";
            }
            break;
        case ConstantPoolInfoTag::INTERFACE_METHODREF:{
            res += "<" + getInterfaceMethodref(cp, index) + ">\n";
            }
            break;
        case ConstantPoolInfoTag::STRING:{
            res += "<" + getString(cp, index) + ">\n";
            }
            break;
        case ConstantPoolInfoTag::INTEGER:{
            res += "<" + std::to_string(getInteger(cp, index)) + ">\n";
            }
            break;
        case ConstantPoolInfoTag::FLOAT:{
            res += "<" + std::to_string(getFloat(cp, index)) + ">\n";
            }
            break;
        case ConstantPoolInfoTag::NAME_AND_TYPE:{
            res += "<" + getNameAndType(cp, index) + ">\n";
            }
            break;
        case ConstantPoolInfoTag::UTF8:{
            res += "<" + getCPUtf8(cp, index) + ">\n";
            }
            break;
        case ConstantPoolInfoTag::METHOD_HANDLE:
            break;
        case ConstantPoolInfoTag::METHOD_TYPE:
            break;
        case ConstantPoolInfoTag::INVOKE_DYNAMIC:
            break;
        default:
            break;
    }
    return res;
}


std::string printOp_ldc_w(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    uint32_t index = bytecode[0];
    index = (index << 8) | bytecode[1];
    res += "ldc_w #" + std::to_string(index);
    switch (cp[index]->tag){
        case ConstantPoolInfoTag::CLASS:{
            res += "<" + getClass(cp, index) + ">\n";
            }
            break;
        case ConstantPoolInfoTag::FIELDREF:{
            res += "<" + getFieldref(cp, index) + ">\n";
            }
            break;
        case ConstantPoolInfoTag::METHODREF:{
            res += "<" + getMethodref(cp, index) + ">\n";
            }
            break;
        case ConstantPoolInfoTag::INTERFACE_METHODREF:{
            res += "<" + getInterfaceMethodref(cp, index) + ">\n";
            }
            break;
        case ConstantPoolInfoTag::STRING:{
            res += "<" + getString(cp, index) + ">\n";
            }
            break;
        case ConstantPoolInfoTag::INTEGER:{
            res += "<" + std::to_string(getInteger(cp, index)) + ">\n";
            }
            break;
        case ConstantPoolInfoTag::FLOAT:{
            res += "<" + std::to_string(getFloat(cp, index)) + ">\n";
            }
            break;
        case ConstantPoolInfoTag::NAME_AND_TYPE:{
            res += "<" + getNameAndType(cp, index) + ">\n";
            }
            break;
        case ConstantPoolInfoTag::UTF8:{
            res += "<" + getCPUtf8(cp, index) + ">\n";
            }
            break;
        case ConstantPoolInfoTag::METHOD_HANDLE:
            break;
        case ConstantPoolInfoTag::METHOD_TYPE:
            break;
        case ConstantPoolInfoTag::INVOKE_DYNAMIC:
            break;
        default:
            break;
    }
    return res;
}

std::string printOp_ldc2_w(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    uint32_t index = bytecode[0];
    index = (index << 8) | bytecode[1];
    res += "ldc2_w #" + std::to_string(index);
    switch (cp[index]->tag){
        case ConstantPoolInfoTag::LONG:{
            res += "<" + std::to_string(getLong(cp, index)) + ">\n";
            }
            break;
        case ConstantPoolInfoTag::DOUBLE:{
            res += "<" + std::to_string(getDouble(cp, index)) + ">\n";
            }
            break;
        default:
            break;
    }
    return res;
}

std::string printOp_iload(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    uint32_t index = bytecode[0];
    res += "iload " + std::to_string(index) + "\n";
    return res;
}

std::string printOp_lload(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    uint32_t index = bytecode[0];
    res += "lload " + std::to_string(index) + "\n";
    return res;
}

std::string printOp_fload(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    uint32_t index = bytecode[0];
    res += "fload " + std::to_string(index) + "\n";
    return res;
}

std::string printOp_dload(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    uint32_t index = bytecode[0];
    res += "dload " + std::to_string(index) + "\n";
    return res;
}

std::string printOp_aload(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    uint32_t index = bytecode[0];
    res += "aload " + std::to_string(index) + "\n";
    return res;
}

std::string printOp_iload_0(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "iload_0\n";
    return res;
}

std::string printOp_iload_1(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "iload_1\n";
    return res;
}

std::string printOp_iload_2(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "iload_2\n";
    return res;
}

std::string printOp_iload_3(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "iload_3\n";
    return res;
}

std::string printOp_lload_0(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "lload_0\n";
    return res;
}

std::string printOp_lload_1(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "lload_1\n";
    return res;
}

std::string printOp_lload_2(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "lload_2\n";
    return res;
}

std::string printOp_lload_3(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "lload_3\n";
    return res;
}

std::string printOp_fload_0(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "fload_0\n";
    return res;
}

std::string printOp_fload_1(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "fload_1\n";
    return res;
}

std::string printOp_fload_2(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "fload_2\n";
    return res;
}

std::string printOp_fload_3(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "fload_3\n";
    return res;
}

std::string printOp_dload_0(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "dload_0\n";
    return res;
}

std::string printOp_dload_1(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "dload_1\n";
    return res;
}

std::string printOp_dload_2(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "dload_2\n";
    return res;
}

std::string printOp_dload_3(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "dload_3\n";
    return res;
}

std::string printOp_aload_0(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "aload_0\n";
    return res;
}

std::string printOp_aload_1(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "aload_1\n";
    return res;
}

std::string printOp_aload_2(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "aload_2\n";
    return res;
}

std::string printOp_aload_3(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "aload_3\n";
    return res;
}

std::string printOp_iaload(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "iaload\n";
    return res;
}

std::string printOp_laload(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "laload\n";
    return res;
}

std::string printOp_faload(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "faload\n";
    return res;
}

std::string printOp_daload(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "daload\n";
    return res;
}

std::string printOp_aaload(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "aaload\n";
    return res;
}

std::string printOp_baload(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "baload\n";
    return res;
}

std::string printOp_caload(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "caload\n";
    return res;
}

std::string printOp_saload(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "saload\n";
    return res;
}

std::string printOp_istore(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    uint32_t index = bytecode[0];
    res += "istore " + std::to_string(index) + "\n";
    return res;
}

std::string printOp_lstore(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    uint32_t index = bytecode[0];
    res += "lstore " + std::to_string(index) + "\n";
    return res;
}

std::string printOp_fstore(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    uint32_t index = bytecode[0];
    res += "fstore " + std::to_string(index) + "\n";
    return res;
}

std::string printOp_dstore(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    uint32_t index = bytecode[0];
    res += "dstore " + std::to_string(index) + "\n";
    return res;
}

std::string printOp_astore(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    uint32_t index = bytecode[0];
    res += "astore " + std::to_string(index) + "\n";
    return res;
}

std::string printOp_istore_0(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "istore_0\n";
    return res;
}

std::string printOp_istore_1(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "istore_1\n";
    return res;
}

std::string printOp_istore_2(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "istore_2\n";
    return res;
}

std::string printOp_istore_3(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "istore_3\n";
    return res;
}

std::string printOp_lstore_0(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "lstore_0\n";
    return res;
}

std::string printOp_lstore_1(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "lstore_1\n";
    return res;
}

std::string printOp_lstore_2(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "lstore_2\n";
    return res;
}

std::string printOp_lstore_3(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "lstore_3\n";
    return res;
}

std::string printOp_fstore_0(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "fstore_0\n";
    return res;
}

std::string printOp_fstore_1(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "fstore_1\n";
    return res;
}

std::string printOp_fstore_2(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "fstore_2\n";
    return res;
}

std::string printOp_fstore_3(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "fstore_3\n";
    return res;
}

std::string printOp_dstore_0(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "dstore_0\n";
    return res;
}

std::string printOp_dstore_1(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "dstore_1\n";
    return res;
}

std::string printOp_dstore_2(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "dstore_2\n";
    return res;
}

std::string printOp_dstore_3(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "dstore_3\n";
    return res;
}

std::string printOp_astore_0(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "astore_0\n";
    return res;
}

std::string printOp_astore_1(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "astore_1\n";
    return res;
}

std::string printOp_astore_2(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "astore_2\n";
    return res;
}

std::string printOp_astore_3(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "astore_3\n";
    return res;
}

std::string printOp_iastore(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "iastore\n";
    return res;
}

std::string printOp_lastore(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "lastore\n";
    return res;
}

std::string printOp_fastore(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "fastore\n";
    return res;
}

std::string printOp_dastore(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "dastore\n";
    return res;
}

std::string printOp_aastore(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "aastore\n";
    return res;
}

std::string printOp_bastore(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "bastore\n";
    return res;
}

std::string printOp_castore(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "castore\n";
    return res;
}

std::string printOp_sastore(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "sastore\n";
    return res;
}

std::string printOp_pop(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "pop\n";
    return res;
}

std::string printOp_pop2(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "pop2\n";
    return res;
}

std::string printOp_dup(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "dup\n";
    return res;
}

std::string printOp_dup_x1(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "dup_x1\n";
    return res;
}

std::string printOp_dup_x2(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "dup_x2\n";
    return res;
}

std::string printOp_dup2(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "dup2\n";
    return res;
}

std::string printOp_dup2_x1(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "dup2_x1\n";
    return res;
}

std::string printOp_dup2_x2(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "dup2_x2\n";
    return res;
}

std::string printOp_swap(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "swap\n";
    return res;
}

std::string printOp_iadd(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "iadd\n";
    return res;
}

std::string printOp_ladd(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "ladd\n";
    return res;
}

std::string printOp_fadd(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "fadd\n";
    return res;
}

std::string printOp_dadd(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "dadd\n";
    return res;
}

std::string printOp_isub(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "isub\n";
    return res;
}

std::string printOp_lsub(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "lsub\n";
    return res;
}

std::string printOp_fsub(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "fsub\n";
    return res;
}

std::string printOp_dsub(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "dsub\n";
    return res;
}

std::string printOp_imul(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "imul\n";
    return res;
}

std::string printOp_lmul(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "lmul\n";
    return res;
}

std::string printOp_fmul(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "fmul\n";
    return res;
}

std::string printOp_dmul(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "dmul\n";
    return res;
}

std::string printOp_idiv(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "idiv\n";
    return res;
}

std::string printOp_ldiv(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "ldiv\n";
    return res;
}

std::string printOp_fdiv(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "fdiv\n";
    return res;
}

std::string printOp_ddiv(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "ddiv\n";
    return res;
}

std::string printOp_irem(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "irem\n";
    return res;
}

std::string printOp_lrem(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "lrem\n";
    return res;
}

std::string printOp_frem(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "frem\n";
    return res;
}

std::string printOp_drem(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "drem\n";
    return res;
}

std::string printOp_ineg(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "ineg\n";
    return res;
}

std::string printOp_lneg(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "lneg\n";
    return res;
}

std::string printOp_fneg(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "fneg\n";
    return res;
}

std::string printOp_dneg(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "dneg\n";
    return res;
}

std::string printOp_ishl(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "ishl\n";
    return res;
}

std::string printOp_lshl(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "lshl\n";
    return res;
}

std::string printOp_ishr(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "ishr\n";
    return res;
}

std::string printOp_lshr(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "lshr\n";
    return res;
}

std::string printOp_iushr(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "iushr\n";
    return res;
}

std::string printOp_lushr(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "lushr\n";
    return res;
}

std::string printOp_iand(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "iand\n";
    return res;
}

std::string printOp_land(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "land\n";
    return res;
}

std::string printOp_ior(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "ior\n";
    return res;
}

std::string printOp_lor(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "lor\n";
    return res;
}

std::string printOp_ixor(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "ixor\n";
    return res;
}

std::string printOp_lxor(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "lxor\n";
    return res;
}

std::string printOp_iinc(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "iinc\n";
    return res;
}

std::string printOp_i2l(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "i2l\n";
    return res;
}

std::string printOp_i2f(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "i2f\n";
    return res;
}

std::string printOp_i2d(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "i2d\n";
    return res;
}

std::string printOp_l2i(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "l2i\n";
    return res;
}

std::string printOp_l2f(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "l2f\n";
    return res;
}

std::string printOp_l2d(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "l2d\n";
    return res;
}

std::string printOp_f2i(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "f2i\n";
    return res;
}

std::string printOp_f2l(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "f2l\n";
    return res;
}

std::string printOp_f2d(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "f2d\n";
    return res;
}

std::string printOp_d2i(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "d2i\n";
    return res;
}

std::string printOp_d2l(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "d2l\n";
    return res;
}

std::string printOp_d2f(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "d2f\n";
    return res;
}

std::string printOp_i2b(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "i2b\n";
    return res;
}

std::string printOp_i2c(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "i2c\n";
    return res;
}

std::string printOp_i2s(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "i2s\n";
    return res;
}

std::string printOp_lcmp(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "lcmp\n";
    return res;
}

std::string printOp_fcmpl(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "fcmpl\n";
    return res;
}

std::string printOp_fcmpg(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "fcmpg\n";
    return res;
}

std::string printOp_dcmpl(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "dcmpl\n";
    return res;
}

std::string printOp_dcmpg(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "dcmpg\n";
    return res;
}

std::string printOp_ifeq(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    int16_t branchbyte = (uint16_t) bytecode[0];
    branchbyte = (branchbyte << 8) | (uint16_t) bytecode[1];
    res += "ifeq " + std::to_string(branchbyte) + "\n";
    return res;
}

std::string printOp_ifne(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    int16_t branchbyte = (uint16_t) bytecode[0];
    branchbyte = (branchbyte << 8) | (uint16_t) bytecode[1];
    res += "ifne " + std::to_string(branchbyte) + "\n";
    return res;
}

std::string printOp_iflt(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    int16_t branchbyte = (uint16_t) bytecode[0];
    branchbyte = (branchbyte << 8) | (uint16_t) bytecode[1];
    res += "iflt " + std::to_string(branchbyte) + "\n";
    return res;
}

std::string printOp_ifge(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    int16_t branchbyte = (uint16_t) bytecode[0];
    branchbyte = (branchbyte << 8) | (uint16_t) bytecode[1];
    res += "ifge " + std::to_string(branchbyte) + "\n";
    return res;
}

std::string printOp_ifgt(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    int16_t branchbyte = (uint16_t) bytecode[0];
    branchbyte = (branchbyte << 8) | (uint16_t) bytecode[1];
    res += "ifgt " + std::to_string(branchbyte) + "\n";
    return res;
}

std::string printOp_ifle(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    int16_t branchbyte = (uint16_t) bytecode[0];
    branchbyte = (branchbyte << 8) | (uint16_t) bytecode[1];
    res += "ifle " + std::to_string(branchbyte) + "\n";
    return res;
}

std::string printOp_if_icmpeq(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    int16_t branchbyte = (uint16_t) bytecode[0];
    branchbyte = (branchbyte << 8) | (uint16_t) bytecode[1];
    res += "if_icmpeq " + std::to_string(branchbyte) + "\n";
    return res;
}

std::string printOp_if_icmpne(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    int16_t branchbyte = (uint16_t) bytecode[0];
    branchbyte = (branchbyte << 8) | (uint16_t) bytecode[1];
    res += "if_icmpne " + std::to_string(branchbyte) + "\n";
    return res;
}

std::string printOp_if_icmplt(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    int16_t branchbyte = (uint16_t) bytecode[0];
    branchbyte = (branchbyte << 8) | (uint16_t) bytecode[1];
    res += "if_icmplt " + std::to_string(branchbyte) + "\n";
    return res;
}

std::string printOp_if_icmpge(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    int16_t branchbyte = (uint16_t) bytecode[0];
    branchbyte = (branchbyte << 8) | (uint16_t) bytecode[1];
    res += "if_icmpge " + std::to_string(branchbyte) + "\n";
    return res;
}

std::string printOp_if_icmpgt(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    int16_t branchbyte = (uint16_t) bytecode[0];
    branchbyte = (branchbyte << 8) | (uint16_t) bytecode[1];
    res += "if_icmpgt " + std::to_string(branchbyte) + "\n";
    return res;
}

std::string printOp_if_icmple(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    int16_t branchbyte = (uint16_t) bytecode[0];
    branchbyte = (branchbyte << 8) | (uint16_t) bytecode[1];
    res += "if_icmple " + std::to_string(branchbyte) + "\n";
    return res;
}

std::string printOp_if_acmpeq(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    int16_t branchbyte = (uint16_t) bytecode[0];
    branchbyte = (branchbyte << 8) | (uint16_t) bytecode[1];
    res += "if_acmpeq " + std::to_string(branchbyte) + "\n";
    return res;
}

std::string printOp_if_acmpne(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    int16_t branchbyte = (uint16_t) bytecode[0];
    branchbyte = (branchbyte << 8) | (uint16_t) bytecode[1];
    res += "if_acmpne " + std::to_string(branchbyte) + "\n";
    return res;
}

std::string printOp_goto(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    int16_t branchbyte = (uint16_t) bytecode[0];
    branchbyte = (branchbyte << 8) | (uint16_t) bytecode[1];
    res += "goto " + std::to_string(branchbyte) + "\n";
    return res;
}

std::string printOp_jsr(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    int16_t branchbyte = (uint16_t) bytecode[0];
    branchbyte = (branchbyte << 8) | (uint16_t) bytecode[1];
    res += "jsr " + std::to_string(branchbyte) + "\n";
    return res;
}

std::string printOp_ret(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    int16_t branchbyte = (uint16_t) bytecode[0];
    res += "ret " + std::to_string(branchbyte) + "\n";
    return res;
}

std::string printOp_tableswitch(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    int16_t branchbyte = (uint16_t) bytecode[0];
    res += "tableswitch " + std::to_string(branchbyte) + "\n";
    return res;
}

std::string printOp_lookupswitch(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    int16_t branchbyte = (uint16_t) bytecode[0];
    res += "lookupswitch " + std::to_string(branchbyte) + "\n";
    return res;
}

std::string printOp_ireturn(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "ireturn\n";
    return res;
}

std::string printOp_lreturn(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "lreturn\n";
    return res;
}

std::string printOp_freturn(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "freturn\n";
    return res;
}

std::string printOp_dreturn(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "dreturn\n";
    return res;
}

std::string printOp_areturn(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "areturn\n";
    return res;
}

std::string printOp_return(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "return\n";
    return res;
}

std::string printOp_getstatic(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    uint16_t indexbyte = (uint16_t) bytecode[0];
    indexbyte = (indexbyte << 8) | (uint16_t) bytecode[1];
    res += "getstatic " + std::to_string(indexbyte) + "\n";
    return res;
}

std::string printOp_putstatic(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    uint16_t indexbyte = (uint16_t) bytecode[0];
    indexbyte = (indexbyte << 8) | (uint16_t) bytecode[1];
    res += "putstatic " + std::to_string(indexbyte) + "\n";
    return res;
}

std::string printOp_getfield(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    uint16_t indexbyte = (uint16_t) bytecode[0];
    indexbyte = (indexbyte << 8) | (uint16_t) bytecode[1];
    res += "getfield " + std::to_string(indexbyte) + "\n";
    return res;
}

std::string printOp_putfield(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    uint16_t indexbyte = (uint16_t) bytecode[0];
    indexbyte = (indexbyte << 8) | (uint16_t) bytecode[1];
    res += "putfield " + std::to_string(indexbyte) + "\n";
    return res;
}

std::string printOp_invokevirtual(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    uint16_t indexbyte = (uint16_t) bytecode[0];
    indexbyte = (indexbyte << 8) | (uint16_t) bytecode[1];
    res += "invokevirtual #" + std::to_string(indexbyte) + "\n";
    return res;
}

std::string printOp_invokespecial(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    uint16_t indexbyte = (uint16_t) bytecode[0];
    indexbyte = (indexbyte << 8) | (uint16_t) bytecode[1];
    res += "invokespecial #" + std::to_string(indexbyte) + "\n";
    return res;
}

std::string printOp_invokestatic(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    uint16_t indexbyte = (uint16_t) bytecode[0];
    indexbyte = (indexbyte << 8) | (uint16_t) bytecode[1];
    res += "invokestatic #" + std::to_string(indexbyte) + "\n";
    return res;
}

std::string printOp_invokeinterface(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    uint16_t indexbyte = (uint16_t) bytecode[0];
    indexbyte = (indexbyte << 8) | (uint16_t) bytecode[1];
    uint16_t count = (uint16_t) bytecode[2];
    uint16_t zero = (uint16_t) bytecode[3];
    res += "invokeinterface #" + std::to_string(indexbyte) + " " + std::to_string(count) + " " + std::to_string(zero) + "\n";
    return res;
}

std::string printOp_invokedynamic(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    uint16_t indexbyte = (uint16_t) bytecode[0];
    indexbyte = (indexbyte << 8) | (uint16_t) bytecode[1];
    uint16_t zero1 = (uint16_t) bytecode[2];
    uint16_t zero2 = (uint16_t) bytecode[3];
    res += "invokedynamic #" + std::to_string(indexbyte) + " " + std::to_string(zero1) + " " + std::to_string(zero2) + "\n";
    return res;
}

std::string printOp_new(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    uint16_t indexbyte = (uint16_t) bytecode[0];
    indexbyte = (indexbyte << 8) | (uint16_t) bytecode[1];
    res += "new #" + std::to_string(indexbyte) + "\n";
    return res;
}

std::string printOp_newarray(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    uint16_t atype = (uint16_t) bytecode[0];
    res += "newarray " + std::to_string(atype) + "\n";
    return res;
}

std::string printOp_anewarray(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    uint16_t indexbyte = (uint16_t) bytecode[0];
    indexbyte = (indexbyte << 8) | (uint16_t) bytecode[1];
    res += "anewarray #" + std::to_string(indexbyte) + "\n";
    return res;
}

std::string printOp_arraylength(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "arraylength\n";
    return res;
}

std::string printOp_athrow(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "athrow\n";
    return res;
}

std::string printOp_checkcast(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    uint16_t indexbyte = (uint16_t) bytecode[0];
    indexbyte = (indexbyte << 8) | (uint16_t) bytecode[1];
    res += "checkcast #" + std::to_string(indexbyte) + "\n";
    return res;
}

std::string printOp_instanceof(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    uint16_t indexbyte = (uint16_t) bytecode[0];
    indexbyte = (indexbyte << 8) | (uint16_t) bytecode[1];
    res += "instanceof #" + std::to_string(indexbyte) + "\n";
    return res;
}

std::string printOp_monitorenter(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "monitorenter\n";
    return res;
}

std::string printOp_monitorexit(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "monitorexit\n";
    return res;
}

std::string printOp_wide(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    res += "wide\n";
    return res;
}

std::string printOp_multianewarray(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    uint16_t indexbyte = (uint16_t) bytecode[0];
    indexbyte = (indexbyte << 8) | (uint16_t) bytecode[1];
    uint16_t dimensions = (uint16_t) bytecode[2];
    res += "multianewarray #" + std::to_string(indexbyte) + " " + std::to_string(dimensions) + "\n";
    return res;
}

std::string printOp_ifnull(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    int16_t branchbyte = (uint16_t) bytecode[0];
    branchbyte = (branchbyte << 8) | (uint16_t) bytecode[1];
    res += "ifnull " + std::to_string(branchbyte) + "\n";
    return res;
}

std::string printOp_ifnonull(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    int16_t branchbyte = (uint16_t) bytecode[0];
    branchbyte = (branchbyte << 8) | (uint16_t) bytecode[1];
    res += "ifnonull " + std::to_string(branchbyte) + "\n";
    return res;
}

std::string printOp_goto_w(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    int32_t branchbyte = (uint16_t) bytecode[0];
    branchbyte = (branchbyte << 8) | (uint16_t) bytecode[1];
    branchbyte = (branchbyte << 8) | (uint16_t) bytecode[2];
    branchbyte = (branchbyte << 8) | (uint16_t) bytecode[3];
    res += "goto_w " + std::to_string(branchbyte) + "\n";
    return res;
}

std::string printOp_jsr_w(ConstantPoolInfo** cp, const uint8_t* bytecode, uint32_t size){
    std::string res;
    int32_t branchbyte = (uint16_t) bytecode[0];
    branchbyte = (branchbyte << 8) | (uint16_t) bytecode[1];
    branchbyte = (branchbyte << 8) | (uint16_t) bytecode[2];
    branchbyte = (branchbyte << 8) | (uint16_t) bytecode[3];
    res += "jsr_w " + std::to_string(branchbyte) + "\n";
    return res;
}

const std::vector<std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>> printMnemonic({
    printOp_nop, // 0x00
    printOp_aconst_null, // 0x01
    printOp_iconst_m1, // 0x02
    printOp_iconst_0, // 0x03
    printOp_iconst_1, // 0x04
    printOp_iconst_2, // 0x05
    printOp_iconst_3, // 0x06
    printOp_iconst_4, // 0x07
    printOp_iconst_5, // 0x08
    printOp_lconst_0, // 0x09
    printOp_lconst_1, // 0x0A
    printOp_fconst_0, // 0x0B
    printOp_fconst_1, // 0x0C
    printOp_fconst_2, // 0x0D
    printOp_dconst_0, // 0x0E
    printOp_dconst_1, // 0x0F
    printOp_bipush, // 0x10
    printOp_sipush, // 0x11
    printOp_ldc, // 0x12
    printOp_ldc_w, // 0x13
    printOp_ldc2_w, // 0x14
    printOp_iload, // 0x15
    printOp_lload, // 0x16
    printOp_fload, // 0x17
    printOp_dload, // 0x18
    printOp_aload, // 0x19
    printOp_iload_0, // 0x1A
    printOp_iload_1, // 0x1B
    printOp_iload_2, // 0x1C
    printOp_iload_3, // 0x1D
    printOp_lload_0, // 0x1E
    printOp_lload_1, // 0x1F
    printOp_lload_2, // 0x20
    printOp_lload_3, // 0x21
    printOp_fload_0, // 0x22
    printOp_fload_1, // 0x23
    printOp_fload_2, // 0x24
    printOp_fload_3, // 0x25
    printOp_dload_0, // 0x26
    printOp_dload_1, // 0x27
    printOp_dload_2, // 0x28
    printOp_dload_3, // 0x29
    printOp_aload_0, // 0x2A
    printOp_aload_1, // 0x2B
    printOp_aload_2, // 0x2C
    printOp_aload_3, // 0x2D
    printOp_iaload, // 0x2E
    printOp_laload, // 0x2F
    printOp_faload, // 0x30
    printOp_daload, // 0x31
    printOp_aaload, // 0x32
    printOp_baload, // 0x33
    printOp_caload, // 0x34
    printOp_saload, // 0x35
    printOp_istore, // 0x36
    printOp_lstore, // 0x37
    printOp_fstore, // 0x38
    printOp_dstore, // 0x39
    printOp_astore, // 0x3A
    printOp_istore_0, // 0x3B
    printOp_istore_1, // 0x3C
    printOp_istore_2, // 0x3D
    printOp_istore_3, // 0x3E
    printOp_lstore_0, // 0x3F
    printOp_lstore_1, // 0x40
    printOp_lstore_2, // 0x41
    printOp_lstore_3, // 0x42
    printOp_fstore_0, // 0x43
    printOp_fstore_1, // 0x44
    printOp_fstore_2, // 0x45
    printOp_fstore_3, // 0x46
    printOp_dstore_0, // 0x47
    printOp_dstore_1, // 0x48
    printOp_dstore_2, // 0x49
    printOp_dstore_3, // 0x4A
    printOp_astore_0, // 0x4B
    printOp_astore_1, // 0x4C
    printOp_astore_2, // 0x4D
    printOp_astore_3, // 0x4E
    printOp_iastore, // 0x4F
    printOp_lastore, // 0x50
    printOp_fastore, // 0x51
    printOp_dastore, // 0x52
    printOp_aastore, // 0x53
    printOp_bastore, // 0x54
    printOp_castore, // 0x55
    printOp_sastore, // 0x56
    printOp_pop, // 0x57
    printOp_pop2, // 0x58
    printOp_dup, // 0x59
    printOp_dup_x1, // 0x5A
    printOp_dup_x2, // 0x5B
    printOp_dup2, // 0x5C
    printOp_dup2_x1, // 0x5D
    printOp_dup2_x2, // 0x5E
    printOp_swap, // 0x5F
    printOp_iadd, // 0x60
    printOp_ladd, // 0x61
    printOp_fadd, // 0x62
    printOp_dadd, // 0x63
    printOp_isub, // 0x64
    printOp_lsub, // 0x65
    printOp_fsub, // 0x66
    printOp_dsub, // 0x67
    printOp_imul, // 0x68
    printOp_lmul, // 0x69
    printOp_fmul, // 0x6A
    printOp_dmul, // 0x6B
    printOp_idiv, // 0x6C
    printOp_ldiv, // 0x6D
    printOp_fdiv, // 0x6E
    printOp_ddiv, // 0x6F
    printOp_irem, // 0x70
    printOp_lrem, // 0x71
    printOp_frem, // 0x72
    printOp_drem, // 0x73
    printOp_ineg, // 0x74
    printOp_lneg, // 0x75
    printOp_fneg, // 0x76
    printOp_dneg, // 0x77
    printOp_ishl, // 0x78
    printOp_lshl, // 0x79
    printOp_ishr, // 0x7A
    printOp_lshr, // 0x7B
    printOp_iushr, // 0x7C
    printOp_lushr, // 0x7D
    printOp_iand, // 0x7E
    printOp_land, // 0x7F
    printOp_ior, // 0x80
    printOp_lor, // 0x81
    printOp_ixor, // 0x82
    printOp_lxor, // 0x83
    printOp_iinc, // 0x84
    printOp_i2l, // 0x85
    printOp_i2f, // 0x86
    printOp_i2d, // 0x87
    printOp_l2i, // 0x88
    printOp_l2f, // 0x89
    printOp_l2d, // 0x8A
    printOp_f2i, // 0x8B
    printOp_f2l, // 0x8C
    printOp_f2d, // 0x8D
    printOp_d2i, // 0x8E
    printOp_d2l, // 0x8F
    printOp_d2f, // 0x90
    printOp_i2b, // 0x91
    printOp_i2c, // 0x92
    printOp_i2s, // 0x93
    printOp_lcmp, // 0x94
    printOp_fcmpl, // 0x95
    printOp_fcmpg, // 0x96
    printOp_dcmpl, // 0x97
    printOp_dcmpg, // 0x98
    printOp_ifeq, // 0x99
    printOp_ifne, // 0x9A
    printOp_iflt, // 0x9B
    printOp_ifge, // 0x9C
    printOp_ifgt, // 0x9D
    printOp_ifle, // 0x9E
    printOp_if_icmpeq, // 0x9F
    printOp_if_icmpne, // 0xA0
    printOp_if_icmplt, // 0xA1
    printOp_if_icmpge, // 0xA2
    printOp_if_icmpgt, // 0xA3
    printOp_if_icmple, // 0xA4
    printOp_if_acmpeq, // 0xA5
    printOp_if_acmpne, // 0xA6
    printOp_goto, // 0xA7
    printOp_jsr, // 0xA8
    printOp_ret, // 0xA9
    printOp_tableswitch, // 0xAA Atenção
    printOp_lookupswitch, // 0xAB Atenção
    printOp_ireturn, // 0xAC
    printOp_lreturn, // 0xAD
    printOp_freturn, // 0xAE
    printOp_dreturn, // 0xAF
    printOp_areturn, // 0xB0
    printOp_return, // 0xB1
    printOp_getstatic, // 0xB2
    printOp_putstatic, // 0xB3
    printOp_getfield, // 0xB4
    printOp_putfield, // 0xB5
    printOp_invokevirtual, // 0xB6
    printOp_invokespecial, // 0xB7
    printOp_invokestatic, // 0xB8
    printOp_invokeinterface, // 0xB9 Atenção
    printOp_invokedynamic, // 0xBA
    printOp_new, // 0xBB
    printOp_newarray, // 0xBC
    printOp_anewarray, // 0xBD
    printOp_arraylength, // 0xBE
    printOp_athrow, // 0xBF
    printOp_checkcast, // 0xC0
    printOp_instanceof, // 0xC1
    printOp_monitorenter, // 0xC2
    printOp_monitorexit, // 0xC3
    printOp_wide, // 0xC4
    printOp_multianewarray, // 0xC5
    printOp_ifnull, // 0xC6
    printOp_ifnonull, // 0xC7
    printOp_goto_w, // 0xC8
    printOp_jsr_w, // 0xC9
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xCA
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xCB
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xCC
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xCD
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xCE
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xCF
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xD0
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xD1
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xD2
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xD3
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xD4
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xD5
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xD6
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xD7
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xD8
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xD9
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xDA
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xDB
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xDC
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xDD
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xDE
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xDF
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xE0
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xE1
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xE2
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xE3
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xE4
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xE5
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xE6
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xE7
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xE8
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xE9
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xEA
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xEB
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xEC
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xED
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xEE
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xEF
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xF0
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xF1
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xF2
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xF3
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xF4
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xF5
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xF6
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xF7
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xF8
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xF9
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xFA
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xFB
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xFC
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xFD
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>(), // 0xFE
    std::function<std::string(ConstantPoolInfo**, const uint8_t*, uint32_t)>() // 0xFF
});