class if_icmpeq {
    public static void main(String[] args){
        int a = 42;
        if(a != 42){
            System.out.println(12);
        }
        System.out.println(45);
    }
}