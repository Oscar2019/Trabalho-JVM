class print{
    public static void main(String[] args){
        String a = "Olá Mundo";
        // a += 213;
        System.out.println(a);
    }
}