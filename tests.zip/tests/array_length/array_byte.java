class array_byte{
    public static void main(String[] args){
        byte[] vet = new byte[7];
        System.out.println(vet.length);
    }
}