class array_int{
    public static void main(String[] args){
        int[] vet = new int[10];
        System.out.println(vet.length);
    }
}