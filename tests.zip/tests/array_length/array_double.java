class array_double{
    public static void main(String[] args){
        double[] vet = new double[10];
        System.out.println(vet.length);
    }
}