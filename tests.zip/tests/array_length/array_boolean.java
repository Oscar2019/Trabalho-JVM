class array_boolean{
    public static void main(String[] args){
        boolean[] vet = new boolean[5];
        System.out.println(vet.length);
    }
}