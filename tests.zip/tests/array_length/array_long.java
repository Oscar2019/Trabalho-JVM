class array_long{
    public static void main(String[] args){
        long[] vet = new long[10];
        System.out.println(vet.length);
    }
}