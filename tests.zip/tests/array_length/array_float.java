class array_float{
    public static void main(String[] args){
        float[] vet = new float[10];
        System.out.println(vet.length);
    }
}