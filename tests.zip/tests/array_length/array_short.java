class array_short{
    public static void main(String[] args){
        short[] vet = new short[10];
        System.out.println(vet.length);
    }
}