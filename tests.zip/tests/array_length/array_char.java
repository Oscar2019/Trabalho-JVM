class array_char{
    public static void main(String[] args){
        char[] vet = new char[5];
        System.out.println(vet.length);
    }
}