class print_char{
    public static void main(String[] args){
        char a = 'ç';
        // a += 213;
        System.out.println(a);
    }
}