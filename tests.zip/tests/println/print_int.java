class print_int{
    public static void main(String[] args){
        int a = 56;
        // a += 213;
        System.out.println(a);
    }
}