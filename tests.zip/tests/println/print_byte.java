class print_byte{
    public static void main(String[] args){
        byte a = 56;
        // a += 213;
        System.out.println(a);
    }
}