class print_long{
    public static void main(String[] args){
        long a = 56;
        // a += 213;
        System.out.println(a);
    }
}