class print_double{
    public static void main(String[] args){
        double a = 3.14159;
        // a += 213;
        System.out.println(a);
    }
}