class print_float{
    public static void main(String[] args){
        float a = 3.14f;
        // a += 213;
        System.out.println(a);
    }
}