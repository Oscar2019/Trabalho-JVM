class array_boolean{
    public static void main(String[] args){
        boolean[] vet = new boolean[5];
        vet[0] = true;
        vet[1] = true;
        vet[2] = false;
        vet[3] = true;
        vet[4] = false;
        System.out.print("array length: ");
        System.out.println(vet.length);
        System.out.println(vet[0]);
        System.out.println(vet[1]);
        System.out.println(vet[2]);
        System.out.println(vet[3]);
        System.out.println(vet[4]);
    }
}