class array_int{
    public static void main(String[] args){
        int[] vet = new int[10];
        vet[0] = 12;
        vet[1] = 123;
        vet[2] = -6142;
        vet[3] = 342;
        vet[4] = 342;
        vet[5] = 43;
        vet[6] = -432;
        vet[7] = 532;
        vet[8] = 231;
        vet[9] = 1;
        System.out.print("array length: ");
        System.out.println(vet.length);
        System.out.println(vet[0]);
        System.out.println(vet[1]);
        System.out.println(vet[2]);
        System.out.println(vet[3]);
        System.out.println(vet[4]);
        System.out.println(vet[5]);
        System.out.println(vet[6]);
        System.out.println(vet[7]);
        System.out.println(vet[8]);
        System.out.println(vet[9]);
    }
}