class array_float{
    public static void main(String[] args){
        float[] vet = new float[10];
        vet[0] = 3.14f;
        vet[1] = 0.0f;
        vet[2] = -3.14f;
        vet[3] = 34.2f;
        vet[4] = 2.14f;
        vet[5] = 1.24f;
        vet[6] = -4.12f;
        vet[7] = 5.1f;
        vet[8] = 2.12f;
        vet[9] = 1f;
        System.out.print("array length: ");
        System.out.println(vet.length);
        System.out.println(vet[0]);
        System.out.println(vet[1]);
        System.out.println(vet[2]);
        System.out.println(vet[3]);
        System.out.println(vet[4]);
        System.out.println(vet[5]);
        System.out.println(vet[6]);
        System.out.println(vet[7]);
        System.out.println(vet[8]);
        System.out.println(vet[9]);
    }
}