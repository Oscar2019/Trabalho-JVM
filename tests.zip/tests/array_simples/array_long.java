class array_long{
    public static void main(String[] args){
        long[] vet = new long[10];
        vet[0] = 12L;
        vet[1] = 123L;
        vet[2] = -6142L;
        vet[3] = 342L;
        vet[4] = 1000000007L;
        vet[5] = -1000000007L;
        vet[6] = -432L;
        vet[7] = 532L;
        vet[8] = 231L;
        vet[9] = 1L;
        System.out.print("array length: ");
        System.out.println(vet.length);
        System.out.println(vet[0]);
        System.out.println(vet[1]);
        System.out.println(vet[2]);
        System.out.println(vet[3]);
        System.out.println(vet[4]);
        System.out.println(vet[5]);
        System.out.println(vet[6]);
        System.out.println(vet[7]);
        System.out.println(vet[8]);
        System.out.println(vet[9]);
    }
}