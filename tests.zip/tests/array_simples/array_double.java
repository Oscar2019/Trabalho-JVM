class array_double{
    public static void main(String[] args){
        double[] vet = new double[10];
        vet[0] = 3.14;
        vet[1] = 0.0;
        vet[2] = -3.14;
        vet[3] = 34.2;
        vet[4] = 2.14;
        vet[5] = 1.24;
        vet[6] = -4.12;
        vet[7] = 5.1;
        vet[8] = 2.12;
        vet[9] = 1;
        System.out.print("array length: ");
        System.out.println(vet.length);
        System.out.println(vet[0]);
        System.out.println(vet[1]);
        System.out.println(vet[2]);
        System.out.println(vet[3]);
        System.out.println(vet[4]);
        System.out.println(vet[5]);
        System.out.println(vet[6]);
        System.out.println(vet[7]);
        System.out.println(vet[8]);
        System.out.println(vet[9]);
    }
}