class add{
    public static void main(String[] args){
        int pi1 = 12;
        int pi2 = 123231;
        System.out.println(pi1 + pi2);
    }
}