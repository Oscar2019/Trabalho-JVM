class static_field{
    public static boolean var01 = true; 
    public static byte var02 = 12; 
    public static char var03 = 'O'; 
    public static double var04 = 3.14; 
    public static float var05 = 1.2f; 
    public static int var06 = 5; 
    public static long var07 = 1000000007; 
    public static short var08 = 100; 
    public static String var09 = "Quero um 10!"; 
    public static void main(String[] args){
        System.out.println(var01);
        System.out.println(var02);
        System.out.println(var03);
        System.out.println(var04);
        System.out.println(var05);
        System.out.println(var06);
        System.out.println(var07);
        System.out.println(var08);
        System.out.println(var09);
    }
}