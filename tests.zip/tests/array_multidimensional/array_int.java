class array_int{
    public static void main(String[] args){
        int[][] mat = new int[2][2];
        mat[0][0] = 1;
        mat[0][1] = -1;
        mat[1][0] = 2;
        mat[1][1] = 5;
        System.out.println(mat[0][0]);
        System.out.println(mat[0][1]);
        System.out.println(mat[1][0]);
        System.out.println(mat[1][1]);
    }
}