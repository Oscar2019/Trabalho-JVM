class add{
    public static void main(String[] args){
        float pi1 = 3.14f;
        float pi2 = 0.0015f;
        System.out.println(pi1 + pi2);
    }
}