class mul{
    public static void main(String[] args){
        float pi1 = 3.14f;
        float pi2 = 0.1015f;
        System.out.println(pi1 * pi2);
    }
}
