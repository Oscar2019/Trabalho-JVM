class mul{
    public static void main(String[] args){
        double pi1 = 3.14;
        double pi2 = 0.1015;
        System.out.println(pi1 * pi2);
    }
}
