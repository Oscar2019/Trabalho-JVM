class metodo_estatico{
    public static void ola(){
        System.out.println("Olá mundo!");
    }
    public static void main(String[] args){
        ola();
    }
}