class mul{
    public static void main(String[] args){
        long pi1 = 1000000007L;
        long pi2 = 123L;
        System.out.println(pi1 * pi2);
    }
}