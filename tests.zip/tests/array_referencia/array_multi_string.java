class array_multi_string{
    public static void main(String[] args){
        String[] vet = new String[4];
        vet[0] = "Olá mundo";
        vet[1] = "Hello world";
        vet[2] = "Hola mundo";
        vet[3] = "Bonjour le monde";
        System.out.println(vet[0]);
        System.out.println(vet[1]);
        System.out.println(vet[2]);
        System.out.println(vet[3]);
    }
}