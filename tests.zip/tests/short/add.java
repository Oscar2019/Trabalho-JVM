class add{
    public static void main(String[] args){
        short pi1 = 123;
        short pi2 = 1233;
        System.out.println(pi1 + pi2);
    }
}