class invokestatic{
    public static void meth1(){
        System.out.println(3);
    }
    public static void main(String[] args){
        invokestatic.meth1();
    }
}